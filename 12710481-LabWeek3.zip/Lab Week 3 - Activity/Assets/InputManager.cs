﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class InputManager : MonoBehaviour {
	private Transform[] transArray;
	// Use this for initialization
	public Color newRColor, newBColor;
	public Component pahComponent;
	public GameObject[] gameObjects;

	void Start () {
		transArray = new Transform[2];
		transArray [0] = GameObject.FindGameObjectWithTag ("Red").GetComponent<Transform>();
		transArray [1] = GameObject.FindGameObjectWithTag ("Blue").GetComponent<Transform>();
 	}

	// Update is called once per frame
	void Update () {
		if (Input.GetKeyDown (KeyCode.W)) {
			transArray [0].Rotate (0, 0, 45);
			transArray [1].Rotate (0, 0, 45);
		}
		if (Input.GetButtonDown ("Q")) {
			float temp = transArray [0].position.y;
			transArray [0].position = new Vector3 (transArray [0].position.x, transArray [1].position.y, transArray [0].position.z);
			transArray [1].position = new Vector3 (transArray [1].position.x, temp, transArray [1].position.z);

		}
	
		if (Input.GetKeyUp (KeyCode.Q)) {
			newRColor = new Color (Random.Range (51 / 255f, 255 / 255f), 0, 0, 1f);
			newBColor = new Color (0, 0, Random.Range (51 / 255f, 255 / 255f), 1f);
			transArray [0].GetComponentInChildren<Renderer> ().material.color = newRColor;
			transArray [1].GetComponentInChildren<Renderer> ().material.color = newBColor;
			Debug.Log ("Red: " + newRColor);
			Debug.Log ("Blue: " + newBColor);
		}
			
		if (Input.GetKeyDown (KeyCode.E))
		{
			gameObjects = new GameObject[2];
		 	gameObjects [0] = GameObject.Find ("redObj");
		 	gameObjects [1] = GameObject.Find ("blueObj");

			foreach (GameObject go in gameObjects) 
			{
				pahComponent = go.GetComponent<PrintAndHide> (); 
				if (pahComponent!= null) 
				{
					Destroy (pahComponent);
				} 
				else
					go.AddComponent<PrintAndHide> ();
			}
		}
	}
}
